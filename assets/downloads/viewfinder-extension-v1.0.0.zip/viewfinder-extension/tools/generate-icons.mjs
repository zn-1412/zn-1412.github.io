import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { deflateSync } from "node:zlib";

const SIZES = [16, 32, 48, 128];
const SUPERSAMPLE = 4;
const ICON_DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "icons");

const COLORS = {
  accent: [239, 77, 37],
  cream: [251, 247, 236],
};

function drawIcon(size) {
  const scale = size * SUPERSAMPLE;
  const buffer = new Float64Array(scale * scale * 4);
  const unit = scale / 32;

  const setPixel = (x, y, color, alpha = 1) => {
    const offset = (y * scale + x) * 4;
    buffer[offset] = color[0];
    buffer[offset + 1] = color[1];
    buffer[offset + 2] = color[2];
    buffer[offset + 3] = alpha;
  };

  // Rounded orange tile.
  const radius = 8 * unit;
  for (let y = 0; y < scale; y += 1) {
    for (let x = 0; x < scale; x += 1) {
      const px = x + 0.5;
      const py = y + 0.5;
      const cornerX = Math.min(Math.max(px, radius), scale - radius);
      const cornerY = Math.min(Math.max(py, radius), scale - radius);
      if (Math.hypot(px - cornerX, py - cornerY) <= radius) {
        setPixel(x, y, COLORS.accent);
      }
    }
  }

  const stroke = 2.2 * unit;
  const inset = 9 * unit;
  const arm = 5 * unit;
  const segments = [
    [inset, inset + arm, inset, inset],
    [inset, inset, inset + arm, inset],
    [scale - inset - arm, inset, scale - inset, inset],
    [scale - inset, inset, scale - inset, inset + arm],
    [inset, scale - inset - arm, inset, scale - inset],
    [inset, scale - inset, inset + arm, scale - inset],
    [scale - inset - arm, scale - inset, scale - inset, scale - inset],
    [scale - inset, scale - inset - arm, scale - inset, scale - inset],
  ];

  const distanceToSegment = (px, py, x1, y1, x2, y2) => {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lengthSquared = dx * dx + dy * dy;
    const t =
      lengthSquared === 0
        ? 0
        : Math.max(
            0,
            Math.min(1, ((px - x1) * dx + (py - y1) * dy) / lengthSquared),
          );
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  };

  const center = scale / 2;
  const dotRadius = 3.1 * unit;
  for (let y = 0; y < scale; y += 1) {
    for (let x = 0; x < scale; x += 1) {
      const px = x + 0.5;
      const py = y + 0.5;
      let onCropMark = false;

      for (const segment of segments) {
        if (distanceToSegment(px, py, ...segment) <= stroke / 2) {
          onCropMark = true;
          break;
        }
      }

      if (onCropMark || Math.hypot(px - center, py - center) <= dotRadius) {
        setPixel(x, y, COLORS.cream);
      }
    }
  }

  const output = Buffer.alloc(size * size * 4);

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let red = 0;
      let green = 0;
      let blue = 0;
      let alpha = 0;

      for (let sy = 0; sy < SUPERSAMPLE; sy += 1) {
        for (let sx = 0; sx < SUPERSAMPLE; sx += 1) {
          const sourceX = x * SUPERSAMPLE + sx;
          const sourceY = y * SUPERSAMPLE + sy;
          const offset = (sourceY * scale + sourceX) * 4;
          const sampleAlpha = buffer[offset + 3];

          red += buffer[offset] * sampleAlpha;
          green += buffer[offset + 1] * sampleAlpha;
          blue += buffer[offset + 2] * sampleAlpha;
          alpha += sampleAlpha;
        }
      }

      const samples = SUPERSAMPLE * SUPERSAMPLE;
      const outputAlpha = alpha / samples;
      const offset = (y * size + x) * 4;

      if (alpha > 0) {
        output[offset] = Math.round(red / alpha);
        output[offset + 1] = Math.round(green / alpha);
        output[offset + 2] = Math.round(blue / alpha);
      }
      output[offset + 3] = Math.round(outputAlpha * 255);
    }
  }

  return output;
}

function crc32(buffer) {
  let crc = 0xffffffff;

  for (const byte of buffer) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1;
    }
  }

  return (crc ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBuffer = Buffer.from(type, "ascii");
  const body = Buffer.concat([typeBuffer, data]);
  const chunk = Buffer.alloc(12 + data.length);

  chunk.writeUInt32BE(data.length, 0);
  body.copy(chunk, 4);
  chunk.writeUInt32BE(crc32(body), 8 + data.length);

  return chunk;
}

function encodePng(pixels, size) {
  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0);
  header.writeUInt32BE(size, 4);
  header[8] = 8;
  header[9] = 6;
  header[10] = 0;
  header[11] = 0;
  header[12] = 0;

  const stride = size * 4;
  const raw = Buffer.alloc((stride + 1) * size);

  for (let y = 0; y < size; y += 1) {
    raw[y * (stride + 1)] = 0;
    pixels.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk("IHDR", header),
    pngChunk("IDAT", deflateSync(raw, { level: 9 })),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);
}

mkdirSync(ICON_DIR, { recursive: true });

for (const size of SIZES) {
  const pixels = drawIcon(size);
  const png = encodePng(pixels, size);
  writeFileSync(join(ICON_DIR, `icon${size}.png`), png);
  console.log(`icons/icon${size}.png`);
}
