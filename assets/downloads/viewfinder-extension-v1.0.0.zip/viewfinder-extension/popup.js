"use strict";

const els = {
  viewfinder: document.getElementById("viewfinder"),
  placeholder: document.getElementById("placeholder"),
  placeholderTitle: document.getElementById("placeholderTitle"),
  placeholderDetail: document.getElementById("placeholderDetail"),
  shot: document.getElementById("shot"),
  flash: document.getElementById("flash"),
  source: document.getElementById("source"),
  dimensions: document.getElementById("dimensions"),
  capturedAt: document.getElementById("capturedAt"),
  captureButton: document.getElementById("captureButton"),
  captureLabel: document.getElementById("captureLabel"),
  copyButton: document.getElementById("copyButton"),
  downloadButton: document.getElementById("downloadButton"),
  toast: document.getElementById("toast"),
};

const state = {
  blob: null,
  objectUrl: null,
  capturedAt: null,
  sourceName: "当前页面",
  busy: false,
  failed: false,
  lastCaptureAt: 0,
  flashTimer: null,
  toastTimer: null,
};

const MIN_CAPTURE_INTERVAL_MS = 600;

init();

function init() {
  bindControls();
  showLoadingPlaceholder();
  syncControls();

  // Give the popup a frame to paint before asking the browser for the capture.
  requestAnimationFrame(() => {
    window.setTimeout(captureScreen, 40);
  });
}

function bindControls() {
  els.captureButton.addEventListener("click", captureScreen);
  els.copyButton.addEventListener("click", copyScreenshot);
  els.downloadButton.addEventListener("click", downloadScreenshot);
}

async function captureScreen() {
  if (state.busy) {
    return;
  }

  state.busy = true;
  state.failed = false;
  els.viewfinder.classList.remove("is-error");
  hideToast();
  syncControls();

  if (!state.blob) {
    showLoadingPlaceholder();
  }

  try {
    const tab = await getActiveTab();
    updateSource(tab);

    if (!tab || typeof tab.windowId !== "number") {
      throw new CaptureError("NO_ACTIVE_TAB");
    }

    if (isRestrictedPage(tab.url)) {
      throw new CaptureError("RESTRICTED_PAGE");
    }

    const cooldown =
      MIN_CAPTURE_INTERVAL_MS - (Date.now() - state.lastCaptureAt);
    if (cooldown > 0) {
      await delay(cooldown);
    }
    state.lastCaptureAt = Date.now();

    const dataUrl = await captureVisibleTab(tab.windowId);
    const blob = dataUrlToBlob(dataUrl);
    await displayScreenshot(blob);

    state.failed = false;
    fireShutterFlash();
  } catch (error) {
    console.error("Capture failed:", error);
    state.failed = true;
    showCaptureError(error);
  } finally {
    state.busy = false;
    syncControls();
  }
}

function getActiveTab() {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new CaptureError("TAB_QUERY_FAILED", runtimeError.message));
          return;
        }
        resolve(tabs && tabs[0] ? tabs[0] : null);
      });
    } catch (error) {
      reject(new CaptureError("TAB_QUERY_FAILED", error.message));
    }
  });
}

function captureVisibleTab(windowId) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.captureVisibleTab(
        windowId,
        { format: "png" },
        (dataUrl) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            reject(new CaptureError("CAPTURE_FAILED", runtimeError.message));
            return;
          }
          if (!dataUrl) {
            reject(new CaptureError("EMPTY_CAPTURE"));
            return;
          }
          resolve(dataUrl);
        },
      );
    } catch (error) {
      reject(new CaptureError("CAPTURE_FAILED", error.message));
    }
  });
}

function dataUrlToBlob(dataUrl) {
  const commaIndex = dataUrl.indexOf(",");
  if (commaIndex === -1) {
    throw new CaptureError("INVALID_IMAGE");
  }

  const binary = atob(dataUrl.slice(commaIndex + 1));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }

  return new Blob([bytes], { type: "image/png" });
}

function preloadImage(url) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      resolve({
        width: image.naturalWidth,
        height: image.naturalHeight,
      });
    };
    image.onerror = () => {
      reject(new CaptureError("IMAGE_DECODE_FAILED"));
    };
    image.src = url;
  });
}

async function displayScreenshot(blob) {
  const nextUrl = URL.createObjectURL(blob);
  let size;

  try {
    size = await preloadImage(nextUrl);
  } catch (error) {
    URL.revokeObjectURL(nextUrl);
    throw error;
  }

  const previousUrl = state.objectUrl;
  state.blob = blob;
  state.objectUrl = nextUrl;
  state.capturedAt = new Date();

  els.shot.src = nextUrl;
  els.shot.hidden = false;
  els.placeholder.hidden = true;
  els.viewfinder.classList.remove("is-loading", "is-error");
  els.dimensions.textContent = `${size.width} × ${size.height}`;
  els.capturedAt.textContent = formatClock(state.capturedAt);
  els.capturedAt.dateTime = state.capturedAt.toISOString();
  restartAnimation(els.shot, "is-visible");

  if (previousUrl) {
    URL.revokeObjectURL(previousUrl);
  }
}

function updateSource(tab) {
  let label = "当前页面";
  let detail = "";

  if (tab) {
    detail = [tab.title, tab.url].filter(Boolean).join("\n");

    try {
      const url = new URL(tab.url || "");
      if (url.protocol === "file:") {
        label = "本地文件";
      } else if (url.protocol === "http:" || url.protocol === "https:") {
        label = url.hostname.replace(/^www\./i, "") || "当前页面";
      } else {
        label = "浏览器页面";
      }
    } catch (error) {
      label = "当前页面";
    }
  }

  state.sourceName = label;
  els.source.textContent = label;
  els.source.title = detail || label;
}

function isRestrictedPage(rawUrl) {
  if (!rawUrl) {
    return false;
  }

  const url = rawUrl.toLowerCase();

  if (
    [
      "chrome:",
      "edge:",
      "about:",
      "chrome-extension:",
      "edge-extension:",
      "extension:",
      "devtools:",
      "view-source:",
    ].some((prefix) => url.startsWith(prefix))
  ) {
    return true;
  }

  return (
    url.startsWith("https://chromewebstore.google.com/") ||
    url.startsWith("https://chrome.google.com/webstore") ||
    url.startsWith("https://microsoftedge.microsoft.com/addons")
  );
}

function showLoadingPlaceholder() {
  els.placeholder.hidden = false;
  els.placeholderTitle.textContent = "正在取景…";
  els.placeholderDetail.hidden = true;
  els.viewfinder.classList.remove("is-error");
  els.viewfinder.classList.add("is-loading");

  if (!state.blob) {
    els.shot.hidden = true;
  }
}

function showCaptureError(error) {
  const message = describeCaptureError(error);
  els.viewfinder.classList.remove("is-loading");
  els.viewfinder.classList.add("is-error");

  if (state.blob) {
    showToast(message);
    return;
  }

  els.shot.hidden = true;
  els.placeholder.hidden = false;
  els.placeholderTitle.textContent = "无法截取当前页面";
  els.placeholderDetail.textContent = message;
  els.placeholderDetail.hidden = false;
}

function describeCaptureError(error) {
  const code = error && error.code ? error.code : "CAPTURE_FAILED";
  const details = error && error.message ? error.message : "";

  if (code === "RESTRICTED_PAGE") {
    return "浏览器内置页面、扩展商店和受保护页面不允许扩展截图。切换到普通网页后再试。";
  }

  if (code === "NO_ACTIVE_TAB") {
    return "没有找到当前标签页。请关闭这个窗口，回到网页后重新点击扩展图标。";
  }

  if (
    /cannot be captured|not allowed|activeTab|permission|chrome:\/\//i.test(
      details,
    )
  ) {
    return "浏览器没有授予截图权限。请切换到普通网页，重新点击扩展图标。";
  }

  return "画面没有成功返回。该页面可能受到保护，或截图权限被其他扩展占用。请切换页面后再试。";
}

function syncControls() {
  const hasShot = Boolean(state.blob);

  els.captureButton.disabled = state.busy;
  els.copyButton.disabled = state.busy || !hasShot;
  els.downloadButton.disabled = state.busy || !hasShot;

  if (state.busy) {
    els.captureLabel.textContent = hasShot ? "正在截取…" : "正在取景…";
  } else if (hasShot) {
    els.captureLabel.textContent = "重新截取";
  } else if (state.failed) {
    els.captureLabel.textContent = "再试一次";
  } else {
    els.captureLabel.textContent = "截取当前画面";
  }

  els.viewfinder.setAttribute("aria-busy", String(state.busy));
  els.viewfinder.classList.toggle("is-busy", state.busy && hasShot);
}

async function copyScreenshot() {
  if (!state.blob) {
    return;
  }

  if (!navigator.clipboard || typeof ClipboardItem === "undefined") {
    showToast("当前浏览器不支持复制图片，请下载 PNG");
    return;
  }

  try {
    await navigator.clipboard.write([
      new ClipboardItem({ "image/png": state.blob }),
    ]);
    showToast("图片已复制到剪贴板");
  } catch (error) {
    console.error("Copy failed:", error);
    showToast("复制失败，请改用下载");
  }
}

function downloadScreenshot() {
  if (!state.objectUrl) {
    return;
  }

  const link = document.createElement("a");
  link.href = state.objectUrl;
  link.download = buildFilename();
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();

  showToast("PNG 正在下载");
}

function buildFilename() {
  const date = state.capturedAt || new Date();
  const stamp = [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    "-",
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join("");

  const safeSource =
    state.sourceName
      .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, "-")
      .replace(/\s+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "screenshot";

  return `${safeSource}-${stamp}.png`;
}

function formatClock(date) {
  return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function pad(value) {
  return String(value).padStart(2, "0");
}

function fireShutterFlash() {
  window.clearTimeout(state.flashTimer);
  restartAnimation(els.flash, "is-firing");
  state.flashTimer = window.setTimeout(() => {
    els.flash.classList.remove("is-firing");
  }, 440);
}

function restartAnimation(element, className) {
  element.classList.remove(className);
  // Force a reflow so the same animation can play again.
  void element.offsetWidth;
  element.classList.add(className);
}

function showToast(message) {
  window.clearTimeout(state.toastTimer);
  els.toast.textContent = message;
  els.toast.hidden = false;

  state.toastTimer = window.setTimeout(() => {
    els.toast.hidden = true;
  }, 2400);
}

function hideToast() {
  window.clearTimeout(state.toastTimer);
  els.toast.hidden = true;
}

function delay(milliseconds) {
  return new Promise((resolve) => {
    window.setTimeout(resolve, milliseconds);
  });
}

class CaptureError extends Error {
  constructor(code, message = "") {
    super(message || code);
    this.name = "CaptureError";
    this.code = code;
  }
}
